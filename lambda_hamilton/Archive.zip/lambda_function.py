import json
import subprocess
import os

INPUT_PATH = "/tmp"
OUTPUT_PATH = "/tmp"
HAMILTON_PATH = "./bin/hamilton-v1.1.0-linux-amd64"


def exec_hamilton(cmd):
    print(">> start exec hamilton")
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
        print(">> Output:", output.decode('utf-8'))
    except subprocess.CalledProcessError as e:
        print(">> Error output:", e.output.decode('utf-8'))
        raise e

    print(">> hamilton finished")


def lambda_handler(event, context):
    ticket_input = {
        "id": "12345678-1234-1234-1234-123456789012",
        "name": "Evan Hughes",
        "email": "example@uq.edu.au",
        "concert": {
            "id": "12345678-1234-1234-1234-123456789012",
            "name": "Phantom of the Opera",
            "date": "2023-06-07",
            "venue": "Sydney Opera House"
        }
    }

    input_path = f"{INPUT_PATH}/{ticket_input['id']}.json"
    output_path = f"{OUTPUT_PATH}/{ticket_input['id']}"

    with open(input_path, "w") as f:
        json.dump(ticket_input, f)

    cmd = f"{HAMILTON_PATH} generate ticket --input {input_path} --output {output_path}"
